# from nanome_GlycamCB import GlycamCB
import GlycamCB

if __name__ == "__main__":
    GlycamCB.main()
